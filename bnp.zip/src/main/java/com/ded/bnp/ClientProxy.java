package com.ded.bnp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Клиентский прокси-класс для регистрации моделей и рендеров
 */
public class ClientProxy extends CommonProxy {
    
    private static final Logger LOGGER = LogManager.getLogger(Tags.MODID);

    /**
     * Регистрация рендеров блоков
     */
    @SubscribeEvent
    public void registerRenders() {
        ModBlocks.Render();
    }
    
    /**
     * Регистрация моделей для всех блоков и предметов мода
     */
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        LOGGER.info("[BNP] Начало регистрации моделей");
        
        registerPortalCoreModels();
        registerCustomPortalModels();
        
        // Регистрация моделей предметов
        ModItems.initModels();
        
        // Регистрация модели предмета для ядра портала
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 0,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "inventory")
        );
        LOGGER.info("[BNP] Регистрация моделей завершена");
    }
    
    /**
     * Регистрация моделей для ядра портала
     */
    private static void registerPortalCoreModels() {
        // Неактивное ядро, все направления
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 0,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=false,facing=north")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 1,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=false,facing=south")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 2,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=false,facing=east")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 3,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=false,facing=west")
        );
        
        // Активное ядро, все направления
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 4,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=true,facing=north")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 5,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=true,facing=south")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 6,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=true,facing=east")
        );
        ModelLoader.setCustomModelResourceLocation(
                Item.getItemFromBlock(ModBlocks.PortalCore), 7,
                new ModelResourceLocation(ModBlocks.PortalCore.getRegistryName(), "active=true,facing=west")
        );
    }
    
    /**
     * Регистрация моделей для кастомного портала
     */
    private static void registerCustomPortalModels() {
        LOGGER.info("[BNP] Регистрация моделей для кастомного портала");
        
        try {
            // Регистрируем модели для всех направлений портала
            String[] directions = {"north", "south", "east", "west"};
            for (int i = 0; i < directions.length; i++) {
                ModelResourceLocation modelLoc = new ModelResourceLocation(
                        ModBlocks.CustomPortal.getRegistryName(), "facing=" + directions[i]);
                        
                ModelLoader.setCustomModelResourceLocation(
                        Item.getItemFromBlock(ModBlocks.CustomPortal), i, modelLoc
                );
            }
        } catch (Exception e) {
            LOGGER.error("[BNP] Ошибка при регистрации моделей для кастомного портала: " + e.getMessage());
        }
    }
}
